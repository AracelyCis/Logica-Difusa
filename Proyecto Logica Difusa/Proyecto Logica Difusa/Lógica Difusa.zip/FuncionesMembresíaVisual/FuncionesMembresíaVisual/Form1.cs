namespace FuncionesMembresíaVisual
{
    public partial class Form1 : Form
    {
        double comida, servicio, propina;
        public Form1()
        {
            InitializeComponent();
            comida = 0;
            servicio = 0;
            propina = 0;

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            comida = trackBar1.Value;
            servicio = trackBar2.Value;

            // Definición de las funciones de membresía para comida
            double desagradableC = Program.membresíaTrapezoidal(comida, 1, 1, 3, 5);
            double aceptableC = Program.membresíaTrapezoidal(comida, 4, 5, 7, 8);
            double deliciosaC = Program.membresíaTrapezoidal(comida, 7, 8.5, 10, 10);

            // Definición de las funciones de membresía para servicio
            double pesimoS = Program.membresíaTrapezoidal(servicio, 1, 1, 3, 4);
            double promedioS = Program.membresíaTrapezoidal(servicio, 3, 4, 7, 8);
            double excelenteS = Program.membresíaTrapezoidal(servicio, 6.76, 9.74, 10, 10);


            // Definición de las reglas difusas
            double r1 = Math.Min(desagradableC, pesimoS);
            double r2 = Math.Min(desagradableC, promedioS);
            double r3 = Math.Min(desagradableC, excelenteS);
            double r4 = Math.Min(aceptableC, pesimoS);
            double r5 = Math.Min(aceptableC, promedioS);
            double r6 = Math.Min(aceptableC, excelenteS);
            double r7 = Math.Min(deliciosaC, pesimoS);
            double r8 = Math.Min(deliciosaC, promedioS);
            double r9 = Math.Min(deliciosaC, excelenteS);

            double sumaPonderada = 0;
            double sumaDePesos = 0;

            for (double valorPropina = 0; valorPropina <= 20; valorPropina += 0.1)
            {
                double nadaP = Program.membresíaTriangular(valorPropina, 0.0, 0.0, 2.0);
                double pocaP = Program.membresíaTriangular(valorPropina, 1.5, 5.0, 8.0);
                double normalP = Program.membresíaTriangular(valorPropina, 7.0, 10.0, 14.07);
                double generosaP = Program.membresíaTrapezoidal(valorPropina, 12.6, 17.97, 20.0, 20.0);

                //Aquí se empata cada regla con el tipo de propina que le corresponde, para que en saco de poderse aplicar
                //esa regla, se tome ese valor como máximo 
                double membresiaPropina = Math.Max(
                    r1 * nadaP,
                    Math.Max(
                        r2 * nadaP,
                        Math.Max(
                            r3 * pocaP,
                            Math.Max(
                                r4 * nadaP,
                                Math.Max(
                                    r5 * normalP,
                                    Math.Max(
                                        r6 * normalP,
                                        Math.Max(
                                            r7 * nadaP,
                                            Math.Max(
                                                r8 * normalP,
                                                r9 * generosaP
                                            )
                                        )
                                    )
                                )
                            )
                        )
                    )
                );

                sumaPonderada += valorPropina * membresiaPropina;
                sumaDePesos += membresiaPropina;
            }
            // Cálculo del centroide
            propina = sumaPonderada / sumaDePesos;


            string clasificacionPropina = "Desconocida";

            if (propina >= 0.0 && propina <= 2.0)
            {
                clasificacionPropina = "Nada";
            }

            //Se redondea propina a 2 decimales para poder mostrarlo de mejor manera
            propina = Math.Round(propina, 2);
            label1.Text = "El porcentaje de propina apropiado de propina es: " + (clasificacionPropina.Equals("Nada") ? 0.0 : propina) + "%";


        }

        private void trackBar1_ValueChanged(object sender, EventArgs e)
        {
            comida = trackBar1.Value;
            label5.Text = comida + "";
        }

        private void trackBar2_ValueChanged(object sender, EventArgs e)
        {
            servicio = trackBar2.Value;
            label4.Text = servicio + "";
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}