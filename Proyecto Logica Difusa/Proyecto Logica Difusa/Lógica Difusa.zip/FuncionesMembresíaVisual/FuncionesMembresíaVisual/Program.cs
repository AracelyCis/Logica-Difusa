using System.Diagnostics;

namespace FuncionesMembresíaVisual
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            Application.Run(new Form1());
        }

        public static float membresíaBooleana(float x,float x0)
        {
            if(x >= x0)
            {
                return 1;
            }
            else{
                return 0;
            }
        }
        public static float membresíaBooleanaI(float x, float x0)
        {
            if (x <= x0)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }

        public static float membresiaGrado(float x,float x0,float x1)
        {
            if (x <= x0)
            {
                return 0;
            }
            else if(x>x0 && x<x1)
            {
                return pendiente(x0,x1,x); 
            }
            else 
            {
                return 1;
            }
           
        }

        public static float membresiaGradoI(float x, float x0, float x1)
        {
            if (x < x0)
            {
                return 1;
            }
            else if (x >= x0 && x <= x1)
            {
                return pendiente(x0,x1,x);
            }
            else
            {
                return 0;
            }

        }

        public static double membresíaTriangular(double x, double a, double b, double c)
        {
            if (x < a || x > c)
            {
                return 0.0; // x está fuera del rango del triángulo
            }
            else if (x >= a && x < b)
            {
                return (x - a) / (b - a);
            }
            else if (x >= b && x <= c)
            {
                return (c - x) / (c - b);
            }

            return 0.0;
        }


        public static double membresíaTrapezoidal(double x, double a, double b, double c, double d)
        {
            if (a == b && b == c && c == d)
            {
                if (x == a)
                {
                    return 1.0;
                }
                else
                {
                    return 0.0;
                }
            }

            if (x < a || x > d)
            {
                return 0.0; // x está fuera del rango del trapezoide
            }
            else if (x >= a && x < b)
            {
                return (x - a) / (b - a);
            }
            else if (x >= b && x <= c)
            {
                return 1.0;
            }
            else if (x > c && x <= d)
            {
                return (d - x) / (d - c);
            }

            return 0.0;
        }



        public static float pendiente(float x1,float x2,float x)
        {
            
            return ( ((x2*1.0f) - (x1*1.0f)));
        }

    }
}